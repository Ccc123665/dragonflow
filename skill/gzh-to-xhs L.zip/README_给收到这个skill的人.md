# gzh-to-xhs —— 安装说明

把一个公众号链接（或选题）自动重构成小红书图文笔记：文案 + 3:4 竖版配图 + 独立归档。

## 安装（30 秒）

1. 解压，得到文件夹 `gzh-to-xhs`
2. 把整个文件夹放进技能目录：

   | 系统 | 路径 |
   | --- | --- |
   | Windows | `C:\Users\<你的用户名>\.workbuddy\skills\` |
   | macOS / Linux | `~/.workbuddy/skills/` |

   放完应该是：`~/.workbuddy/skills/gzh-to-xhs/SKILL.md`

3. 重启/新建一次对话即可生效。之后直接说「把这个链接转成小红书图文」+ 贴链接就会自动触发。

> 只想给当前项目用？放到 `<项目目录>/.workbuddy/skills/` 下同样有效，且不污染个人技能库。

## 目录结构

```
gzh-to-xhs/
├── SKILL.md              # 主指令，模型按这个执行
├── references/design.md  # 出图设计规范（色板/版式/间距算法）
└── assets/template.py    # 可改造的出图脚本模板
```

## 上手前需要你改的地方

`SKILL.md` 末尾「环境备忘」一节是**作者机器的**踩坑记录（Python 绝对路径、字体路径、DLL 修复等），换机器大概率对不上，建议按你自己的环境改，或整节删掉。

必须确认的两件事：
- Python 能装 PIL：`python -m pip install pillow`（国内加 `-i https://pypi.tuna.tsinghua.edu.cn/simple`）
- 中文字体存在：Windows 用 `C:\Windows\Fonts\msyhbd.ttc`，macOS 换成 `/System/Library/Fonts/PingFang.ttc`

## 安全提示

Skill 本质是「让 AI 照着执行的指令 + 脚本」，收到别人的 skill 请先花一分钟扫一眼 `SKILL.md` 和 `assets/` 里的脚本，确认没有你不希望执行的操作，再放进技能目录。
